"""
main.py
────────────────────────────────────────────────────────────
Entry point for the AI Parking Violation Detection System.

Usage examples
──────────────
  # Live webcam (default)
  python main.py

  # Video file
  python main.py --source path/to/video.mp4

  # RTSP stream
  python main.py --source rtsp://user:pass@192.168.1.1/stream

  # Save annotated output
  python main.py --source video.mp4 --save

  # Draw zones interactively before running
  python main.py --draw-zones

  # Use specific zone file
  python main.py --zones zones/my_zones.json

  # Headless (no window) — e.g. server deployment
  python main.py --source video.mp4 --save --no-preview
────────────────────────────────────────────────────────────
"""

import argparse, os, sys, time

# Ensure project root on path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def parse_args():
    p = argparse.ArgumentParser(
        description="AI Parking Violation Detection System",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument(
        "--source", default="0",
        help="Video source: 0=webcam | video path | RTSP URL  (default: 0)",
    )
    p.add_argument(
        "--zones", default="zones/parking_zones.json",
        help="Path to zones JSON file (default: zones/parking_zones.json)",
    )
    p.add_argument(
        "--output", default=None,
        help="Output video path (default: auto-named in output/)",
    )
    p.add_argument(
        "--save", action="store_true",
        help="Save annotated output video",
    )
    p.add_argument(
        "--no-preview", action="store_true",
        help="Suppress OpenCV preview window (useful for headless servers)",
    )
    p.add_argument(
        "--draw-zones", action="store_true",
        help="Launch interactive zone editor before detection",
    )
    p.add_argument(
        "--model", default=None,
        help="YOLOv8 model: yolov8n | yolov8s | yolov8m | yolov8l (default from config)",
    )
    p.add_argument(
        "--conf", type=float, default=None,
        help="Detection confidence threshold (default from config)",
    )
    p.add_argument(
        "--demo", action="store_true",
        help="Run synthetic demo (no camera needed)",
    )
    return p.parse_args()


def main():
    args = parse_args()

    # ── Apply CLI overrides to config ──────────────────────
    import config as cfg
    if args.model:
        cfg.YOLO_MODEL = args.model + ".pt" if not args.model.endswith(".pt") else args.model
    if args.conf:
        cfg.YOLO_CONF = args.conf

    # ── Source normalization ────────────────────────────────
    source = args.source
    try:
        source = int(source)           # webcam index
    except ValueError:
        pass                           # keep as string path / URL

    # ── Demo mode ──────────────────────────────────────────
    if args.demo:
        print("[Main] Running demo mode …")
        from demo import run_demo
        run_demo()
        return

    # ── Interactive zone drawing ────────────────────────────
    if args.draw_zones:
        import cv2
        from zone_manager import ZoneManager, InteractiveZoneDrawer

        zm  = ZoneManager(args.zones)
        cap = cv2.VideoCapture(source)
        ret, frame = cap.read()
        cap.release()
        if not ret:
            print("[Error] Cannot open source for zone drawing.")
            sys.exit(1)

        drawer = InteractiveZoneDrawer(frame, zm)
        drawer.run()
        zm.save()
        print(f"[Main] Zones saved to '{args.zones}'. Starting detection …")
        time.sleep(1)

    # ── Output path ────────────────────────────────────────
    output_path = None
    if args.save or args.output:
        os.makedirs("output", exist_ok=True)
        if args.output:
            output_path = args.output
        else:
            ts = time.strftime("%Y%m%d_%H%M%S")
            output_path = f"output/parking_output_{ts}.mp4"
        print(f"[Main] Output video → {output_path}")

    # ── Run detector ───────────────────────────────────────
    from parking_detector import ParkingDetector
    detector = ParkingDetector(
        source       = source,
        zones_file   = args.zones,
        output_path  = output_path,
        show_preview = not args.no_preview,
    )
    detector.run()


if __name__ == "__main__":
    main()
