"""
vehicle_tracker.py
────────────────────────────────────────────────────────────
Lightweight multi-object tracker combining:
  • Centroid distance matching
  • IoU-based association (Hungarian-style greedy)
  • Per-track trajectory history
  • Class-label memory
────────────────────────────────────────────────────────────
"""

from __future__ import annotations
import time
from collections import OrderedDict, deque
from typing import Dict, List, Optional, Tuple

import numpy as np

from config import MAX_DISAPPEARED, MAX_DISTANCE, IOU_THRESHOLD


# ═══════════════════════════════════════════════════════════
class VehicleTrack:
    """State for a single tracked vehicle."""

    def __init__(self, track_id: int, bbox: Tuple[int,int,int,int],
                 class_id: int, conf: float):
        self.track_id      = track_id
        self.bbox          = bbox           # (x1,y1,x2,y2)
        self.class_id      = class_id
        self.conf          = conf
        self.disappeared   = 0
        self.age           = 0              # frames alive
        self.first_seen    = time.time()
        self.last_seen     = time.time()

        cx, cy = self._centroid(bbox)
        self.trajectory: deque = deque([(cx, cy)], maxlen=40)

        # Violation tracking
        self.violation_frames  : int  = 0
        self.violating         : bool = False
        self.violated_zone_ids : List[int] = []

    # ── Accessors ──────────────────────────────────────────
    @property
    def centroid(self) -> Tuple[int, int]:
        return self.trajectory[-1]

    @staticmethod
    def _centroid(bbox: Tuple[int,int,int,int]) -> Tuple[int,int]:
        x1, y1, x2, y2 = bbox
        return (x1 + x2) // 2, (y1 + y2) // 2

    def update(self, bbox: Tuple[int,int,int,int],
               class_id: int, conf: float) -> None:
        self.bbox       = bbox
        self.class_id   = class_id
        self.conf       = conf
        self.disappeared = 0
        self.age        += 1
        self.last_seen   = time.time()
        cx, cy = self._centroid(bbox)
        self.trajectory.append((cx, cy))

    def mark_missing(self) -> None:
        self.disappeared += 1

    def update_violation(self, is_violating: bool,
                         zone_ids: List[int],
                         threshold: int) -> bool:
        """Returns True if a NEW violation event just triggered."""
        if is_violating:
            self.violation_frames += 1
            self.violated_zone_ids = zone_ids
        else:
            self.violation_frames = max(0, self.violation_frames - 1)
            if self.violation_frames == 0:
                self.violating = False
                self.violated_zone_ids = []

        if self.violation_frames >= threshold and not self.violating:
            self.violating = True
            return True          # new violation event
        return False

    @property
    def parking_duration(self) -> float:
        return time.time() - self.first_seen


# ═══════════════════════════════════════════════════════════
class VehicleTracker:
    """
    Multi-object vehicle tracker.

    Usage
    ─────
        tracker = VehicleTracker()
        while True:
            detections = yolo.detect(frame)   # [(bbox, class_id, conf), ...]
            tracks = tracker.update(detections)
            for track in tracks:
                draw(frame, track)
    """

    def __init__(self,
                 max_disappeared: int = MAX_DISAPPEARED,
                 max_distance:    int = MAX_DISTANCE,
                 iou_threshold:   float = IOU_THRESHOLD):
        self.max_disappeared = max_disappeared
        self.max_distance    = max_distance
        self.iou_threshold   = iou_threshold

        self._tracks: OrderedDict[int, VehicleTrack] = OrderedDict()
        self._next_id = 0

    # ── Public API ─────────────────────────────────────────
    @property
    def active_tracks(self) -> List[VehicleTrack]:
        return [t for t in self._tracks.values() if t.disappeared == 0]

    @property
    def all_tracks(self) -> List[VehicleTrack]:
        return list(self._tracks.values())

    def update(self,
               detections: List[Tuple[Tuple[int,int,int,int], int, float]]
               ) -> List[VehicleTrack]:
        """
        detections: list of (bbox, class_id, conf)
            bbox = (x1, y1, x2, y2)
        Returns active tracks after update.
        """
        # ── No detections ──────────────────────────────────
        if not detections:
            for track in self._tracks.values():
                track.mark_missing()
            self._prune()
            return self.active_tracks

        # ── No existing tracks ─────────────────────────────
        if not self._tracks:
            for bbox, cls, conf in detections:
                self._register(bbox, cls, conf)
            return self.active_tracks

        # ── Match detections → tracks ──────────────────────
        track_ids   = list(self._tracks.keys())
        track_list  = [self._tracks[i] for i in track_ids]
        det_bboxes  = [d[0] for d in detections]

        # Build cost matrix: centroid distance + IoU penalty
        cost = self._cost_matrix(track_list, det_bboxes)

        # Greedy assignment (lowest cost first)
        matched_tracks = set()
        matched_dets   = set()

        if cost.size > 0:
            flat_order = np.argsort(cost, axis=None)
            rows, cols = np.unravel_index(flat_order, cost.shape)
            for r, c in zip(rows, cols):
                if r in matched_tracks or c in matched_dets:
                    continue
                if cost[r, c] > self.max_distance:
                    break
                bbox, cls, conf = detections[c]
                self._tracks[track_ids[r]].update(bbox, cls, conf)
                matched_tracks.add(r)
                matched_dets.add(c)

        # Mark unmatched tracks as disappeared
        for r, tid in enumerate(track_ids):
            if r not in matched_tracks:
                self._tracks[tid].mark_missing()

        # Register unmatched detections as new tracks
        for c, det in enumerate(detections):
            if c not in matched_dets:
                self._register(*det)

        self._prune()
        return self.active_tracks

    def get_track(self, track_id: int) -> Optional[VehicleTrack]:
        return self._tracks.get(track_id)

    def reset(self) -> None:
        self._tracks.clear()
        self._next_id = 0

    # ── Internals ──────────────────────────────────────────
    def _register(self, bbox, cls, conf) -> VehicleTrack:
        track = VehicleTrack(self._next_id, bbox, cls, conf)
        self._tracks[self._next_id] = track
        self._next_id += 1
        return track

    def _prune(self) -> None:
        dead = [tid for tid, t in self._tracks.items()
                if t.disappeared > self.max_disappeared]
        for tid in dead:
            del self._tracks[tid]

    def _cost_matrix(self,
                     tracks: List[VehicleTrack],
                     det_bboxes: List[Tuple[int,int,int,int]]) -> np.ndarray:
        n_tracks = len(tracks)
        n_dets   = len(det_bboxes)
        cost     = np.full((n_tracks, n_dets), fill_value=9999.0)

        for i, track in enumerate(tracks):
            tcx, tcy = track.centroid
            for j, bbox in enumerate(det_bboxes):
                dcx = (bbox[0] + bbox[2]) // 2
                dcy = (bbox[1] + bbox[3]) // 2
                dist = np.hypot(tcx - dcx, tcy - dcy)

                iou  = _iou(track.bbox, bbox)
                # reward high IoU (subtract up to 80 px from cost)
                cost[i, j] = dist - iou * 80
        return cost


# ─────────────────────────────────────────────────────────
def _iou(boxA: Tuple[int,int,int,int],
          boxB: Tuple[int,int,int,int]) -> float:
    xA = max(boxA[0], boxB[0]); yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2]); yB = min(boxA[3], boxB[3])
    inter = max(0, xB - xA) * max(0, yB - yA)
    if inter == 0:
        return 0.0
    aA = (boxA[2]-boxA[0]) * (boxA[3]-boxA[1])
    aB = (boxB[2]-boxB[0]) * (boxB[3]-boxB[1])
    return inter / float(aA + aB - inter)
