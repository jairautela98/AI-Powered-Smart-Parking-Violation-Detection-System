"""
alert_system.py
────────────────────────────────────────────────────────────
Handles violation alerts:
  • Console + file logging
  • Frame snapshots on first violation
  • CSV violation log
  • In-frame alert banners
  • Summary statistics
────────────────────────────────────────────────────────────
"""

from __future__ import annotations
import csv, json, os, time
from dataclasses import dataclass, asdict, field
from datetime import datetime
from typing import Dict, List, Optional

import cv2
import numpy as np

from config import (
    LOGS_DIR, OUTPUT_DIR,
    ALERT_COOLDOWN, SNAPSHOT_VIOLATIONS,
    COLOUR, VEHICLE_NAMES,
)


# ═══════════════════════════════════════════════════════════
@dataclass
class ViolationRecord:
    violation_id  : int
    track_id      : int
    class_name    : str
    zone_names    : List[str]
    zone_types    : List[str]
    timestamp     : str
    frame_number  : int
    bbox          : List[int]
    snapshot_path : Optional[str] = None
    duration_sec  : float = 0.0


# ═══════════════════════════════════════════════════════════
class AlertSystem:
    """
    Central alert & logging hub.

    Usage
    ─────
        alerts = AlertSystem()
        if new_violation:
            alerts.raise_violation(track, zones, frame, frame_no)
        alerts.draw_hud(frame)
    """

    CSV_HEADERS = [
        "violation_id", "track_id", "class_name",
        "zone_names", "zone_types", "timestamp",
        "frame_number", "bbox", "snapshot_path", "duration_sec",
    ]

    def __init__(self):
        ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.run_id      = ts
        self.log_path    = os.path.join(LOGS_DIR, f"violations_{ts}.csv")
        self.json_path   = os.path.join(LOGS_DIR, f"session_{ts}.json")
        self.snap_dir    = os.path.join(OUTPUT_DIR, f"snapshots_{ts}")

        os.makedirs(self.snap_dir, exist_ok=True)

        self._records     : List[ViolationRecord] = []
        self._vid         : int = 1              # violation id counter
        self._cooldowns   : Dict[int, float] = {} # track_id → last alert time
        self._banner_queue: List[str] = []        # on-frame text queue

        # Stats
        self.total_vehicles_seen : int = 0
        self.total_violations    : int = 0
        self.frames_processed    : int = 0
        self.start_time          : float = time.time()

        self._init_csv()
        print(f"[AlertSystem] Logging to {self.log_path}")

    # ── Main API ───────────────────────────────────────────
    def raise_violation(self,
                        track_id      : int,
                        class_id      : int,
                        zones         ,          # List[ParkingZone]
                        frame         : np.ndarray,
                        frame_number  : int,
                        bbox          : tuple,
                        duration_sec  : float = 0.0) -> bool:
        """
        Call when a track triggers a new violation event.
        Returns True if the alert was actually emitted (respects cooldown).
        """
        now = time.time()
        if now - self._cooldowns.get(track_id, 0) < ALERT_COOLDOWN:
            return False
        self._cooldowns[track_id] = now

        snap_path = None
        if SNAPSHOT_VIOLATIONS:
            snap_path = self._save_snapshot(frame, track_id, frame_number, bbox)

        rec = ViolationRecord(
            violation_id  = self._vid,
            track_id      = track_id,
            class_name    = VEHICLE_NAMES.get(class_id, "Vehicle"),
            zone_names    = [z.name for z in zones],
            zone_types    = [z.zone_type for z in zones],
            timestamp     = datetime.now().isoformat(),
            frame_number  = frame_number,
            bbox          = list(bbox),
            snapshot_path = snap_path,
            duration_sec  = round(duration_sec, 1),
        )
        self._records.append(rec)
        self._append_csv(rec)
        self._vid += 1
        self.total_violations += 1

        banner = (f"⚠  VIOLATION #{rec.violation_id}  |  "
                  f"Track {track_id} ({rec.class_name})  |  "
                  f"Zone: {', '.join(rec.zone_names)}")
        self._banner_queue.append(banner)
        print(f"[ALERT] {banner}")
        return True

    def tick(self, n_vehicles: int) -> None:
        self.frames_processed += 1
        self.total_vehicles_seen = max(self.total_vehicles_seen, n_vehicles)
        # expire old banners (show each for ~3 s = ~75 frames)
        if len(self._banner_queue) > 5:
            self._banner_queue.pop(0)

    # ── HUD ────────────────────────────────────────────────
    def draw_hud(self, frame: np.ndarray, fps: float = 0.0,
                 active_vehicles: int = 0,
                 active_violations: int = 0) -> None:
        h, w = frame.shape[:2]

        # ── Top-left stats panel ─────────────────────────
        elapsed  = time.time() - self.start_time
        lines = [
            f"FPS       : {fps:5.1f}",
            f"Vehicles  : {active_vehicles}",
            f"Violations: {self.total_violations}  (active: {active_violations})",
            f"Runtime   : {int(elapsed//60):02d}:{int(elapsed%60):02d}",
        ]
        panel_w  = 240
        panel_h  = len(lines) * 22 + 12
        overlay  = frame.copy()
        cv2.rectangle(overlay, (5, 5), (panel_w, panel_h), (15, 15, 15), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
        for i, line in enumerate(lines):
            colour = (0, 255, 200) if i == 0 else (200, 200, 200)
            cv2.putText(frame, line,
                        (10, 22 + i * 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.52, colour, 1)

        # ── Alert banners (bottom) ────────────────────────
        for i, banner in enumerate(reversed(self._banner_queue[-3:])):
            by = h - 15 - i * 28
            (bw, bh), _ = cv2.getTextSize(banner, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
            cv2.rectangle(frame, (0, by - bh - 6), (bw + 14, by + 4),
                          COLOUR["alert_banner"], -1)
            cv2.putText(frame, banner, (7, by),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        # ── Title watermark ───────────────────────────────
        title = "AI PARKING VIOLATION DETECTOR"
        cv2.putText(frame, title, (w // 2 - 185, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 220, 255), 2)

    # ── Reports ────────────────────────────────────────────
    def save_session_report(self) -> str:
        elapsed = time.time() - self.start_time
        report = {
            "run_id"               : self.run_id,
            "duration_seconds"     : round(elapsed, 1),
            "frames_processed"     : self.frames_processed,
            "total_violations"     : self.total_violations,
            "total_vehicles_seen"  : self.total_vehicles_seen,
            "violations"           : [asdict(r) for r in self._records],
        }
        with open(self.json_path, "w") as f:
            json.dump(report, f, indent=2)

        print("\n" + "═" * 52)
        print("  SESSION REPORT")
        print("═" * 52)
        print(f"  Duration        : {int(elapsed//60):02d}:{int(elapsed%60):02d}")
        print(f"  Frames          : {self.frames_processed}")
        print(f"  Vehicles seen   : {self.total_vehicles_seen}")
        print(f"  Total violations: {self.total_violations}")
        print(f"  JSON report     : {self.json_path}")
        print(f"  CSV log         : {self.log_path}")
        print("═" * 52 + "\n")
        return self.json_path

    # ── Internals ──────────────────────────────────────────
    def _init_csv(self) -> None:
        with open(self.log_path, "w", newline="") as f:
            csv.writer(f).writerow(self.CSV_HEADERS)

    def _append_csv(self, rec: ViolationRecord) -> None:
        with open(self.log_path, "a", newline="") as f:
            csv.writer(f).writerow([
                rec.violation_id, rec.track_id, rec.class_name,
                "|".join(rec.zone_names),
                "|".join(rec.zone_types),
                rec.timestamp, rec.frame_number,
                f"{rec.bbox}", rec.snapshot_path, rec.duration_sec,
            ])

    def _save_snapshot(self, frame: np.ndarray,
                        track_id: int, frame_no: int,
                        bbox: tuple) -> str:
        x1, y1, x2, y2 = bbox
        pad = 20
        crop = frame[max(0,y1-pad):y2+pad, max(0,x1-pad):x2+pad]
        fname = f"violation_t{track_id}_f{frame_no}.jpg"
        path  = os.path.join(self.snap_dir, fname)
        cv2.imwrite(path, crop if crop.size else frame)
        return path
