"""
parking_detector.py
────────────────────────────────────────────────────────────
Core detection pipeline:
  1. YOLO inference   (YOLOv8 via Ultralytics)
  2. Vehicle tracking (centroid + IoU)
  3. Zone violation   (polygon overlap)
  4. Alert raising    (log + snapshot + banner)
  5. Frame rendering  (boxes, trajectories, zones, HUD)
────────────────────────────────────────────────────────────
"""

from __future__ import annotations
import time
from typing import List, Optional, Tuple

import cv2
import numpy as np

from config import (
    YOLO_MODEL, YOLO_CONF, YOLO_IOU, YOLO_DEVICE, YOLO_IMG_SIZE,
    VEHICLE_CLASS_IDS, VEHICLE_NAMES,
    VIOLATION_FRAME_THRESHOLD,
    COLOUR, FONT_SCALE, FONT_THICK, BOX_THICK,
    SHOW_TRACK_ID, SHOW_CLASS_LABEL, SHOW_CONFIDENCE,
    FRAME_RESIZE_WIDTH,
)
from vehicle_tracker import VehicleTracker, VehicleTrack
from zone_manager    import ZoneManager
from alert_system    import AlertSystem


# ═══════════════════════════════════════════════════════════
class ParkingDetector:
    """
    End-to-end parking violation detector.

    Parameters
    ──────────
    source         : int (webcam) | str (video path / RTSP URL)
    zones_file     : path to JSON zone definitions
    output_path    : path for output video (None → no save)
    show_preview   : open a live OpenCV window
    """

    def __init__(self,
                 source       : int | str = 0,
                 zones_file   : str = "zones/parking_zones.json",
                 output_path  : Optional[str] = None,
                 show_preview : bool = True):

        self.source       = source
        self.output_path  = output_path
        self.show_preview = show_preview

        print("\n" + "═"*54)
        print("  AI PARKING VIOLATION DETECTION SYSTEM  v2.0")
        print("═"*54)

        # ── Components ─────────────────────────────────────
        print("[Init] Loading YOLO model …")
        from ultralytics import YOLO
        self.model    = YOLO(YOLO_MODEL)
        self.model.to(YOLO_DEVICE)

        self.tracker  = VehicleTracker()
        self.zm       = ZoneManager(zones_file)
        self.alerts   = AlertSystem()

        # ── State ──────────────────────────────────────────
        self.frame_no : int   = 0
        self._fps_buf : list  = []
        self._t_last  : float = time.time()

        print(f"[Init] Zones loaded : {len(self.zm.zones)}")
        print(f"[Init] Source       : {source}")
        print("[Init] Ready.\n")

    # ══════════════════════════════════════════════════════
    def run(self) -> None:
        cap = cv2.VideoCapture(self.source)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open source: {self.source}")

        ret, first = cap.read()
        if not ret:
            raise RuntimeError("Cannot read first frame.")

        first = self._resize(first)
        H, W  = first.shape[:2]

        # Load demo zones if none defined
        from zone_manager import load_default_demo_zones
        load_default_demo_zones(self.zm, W, H)

        # Video writer
        writer = None
        if self.output_path:
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(self.output_path, fourcc, 25.0, (W, H))

        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)    # rewind

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                frame = self._resize(frame)
                output = self.process_frame(frame)

                if writer:
                    writer.write(output)

                if self.show_preview:
                    cv2.imshow("AI Parking Violation Detector", output)
                    key = cv2.waitKey(1) & 0xFF
                    if key in (ord('q'), 27):
                        break
                    elif key == ord('s'):
                        path = f"output/snapshot_{self.frame_no}.jpg"
                        cv2.imwrite(path, output)
                        print(f"[Snapshot] Saved {path}")
                    elif key == ord('p'):       # pause
                        cv2.waitKey(0)

        finally:
            cap.release()
            if writer:
                writer.release()
            if self.show_preview:
                cv2.destroyAllWindows()
            self.alerts.save_session_report()

    # ══════════════════════════════════════════════════════
    def process_frame(self, frame: np.ndarray) -> np.ndarray:
        """
        Full pipeline on a single frame.
        Returns an annotated copy.
        """
        self.frame_no += 1
        t0 = time.perf_counter()

        # ── 1. YOLO inference ──────────────────────────────
        results = self.model.predict(
            frame,
            conf     = YOLO_CONF,
            iou      = YOLO_IOU,
            imgsz    = YOLO_IMG_SIZE,
            classes  = VEHICLE_CLASS_IDS,
            verbose  = False,
        )[0]

        detections = self._parse_results(results)

        # ── 2. Track ───────────────────────────────────────
        tracks = self.tracker.update(detections)

        # ── 3. Zone violation check ────────────────────────
        active_violations = 0
        for track in tracks:
            zones = self.zm.get_all_violations(track.bbox)
            is_v  = bool(zones)
            new_v = track.update_violation(
                is_v,
                [z.zone_id for z in zones],
                VIOLATION_FRAME_THRESHOLD,
            )
            if new_v:
                self.alerts.raise_violation(
                    track_id     = track.track_id,
                    class_id     = track.class_id,
                    zones        = zones,
                    frame        = frame,
                    frame_number = self.frame_no,
                    bbox         = track.bbox,
                    duration_sec = track.parking_duration,
                )
            if track.violating:
                active_violations += 1

        # ── 4. Render ──────────────────────────────────────
        out = frame.copy()
        self.zm.draw_all(out)
        self._draw_tracks(out, tracks)

        fps = self._calc_fps(t0)
        self.alerts.tick(len(tracks))
        self.alerts.draw_hud(out, fps=fps,
                             active_vehicles=len(tracks),
                             active_violations=active_violations)
        return out

    # ══════════════════════════════════════════════════════
    # Drawing helpers
    # ══════════════════════════════════════════════════════
    def _draw_tracks(self, frame: np.ndarray,
                     tracks: List[VehicleTrack]) -> None:
        for track in tracks:
            self._draw_single_track(frame, track)

    def _draw_single_track(self, frame: np.ndarray,
                           track: VehicleTrack) -> None:
        x1, y1, x2, y2 = track.bbox
        violating = track.violating

        # ── Bounding box ──────────────────────────────────
        box_colour = COLOUR["violation_box"] if violating else COLOUR["normal_box"]
        cv2.rectangle(frame, (x1, y1), (x2, y2), box_colour, BOX_THICK)

        # ── Flashing red border on violation ──────────────
        if violating and (self.frame_no % 8 < 4):
            cv2.rectangle(frame, (x1-3, y1-3), (x2+3, y2+3),
                          (0, 0, 255), 2)

        # ── Label ─────────────────────────────────────────
        parts = []
        if SHOW_TRACK_ID:
            parts.append(f"ID:{track.track_id}")
        if SHOW_CLASS_LABEL:
            parts.append(VEHICLE_NAMES.get(track.class_id, "V"))
        if SHOW_CONFIDENCE:
            parts.append(f"{track.conf:.2f}")
        label = "  ".join(parts)

        (tw, th), bl = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX,
                                        FONT_SCALE, FONT_THICK)
        lx, ly = x1, y1 - 6
        if ly - th < 0:
            ly = y2 + th + 4

        cv2.rectangle(frame, (lx, ly - th - 3), (lx + tw + 6, ly + bl),
                      box_colour, -1)
        cv2.putText(frame, label, (lx + 3, ly),
                    cv2.FONT_HERSHEY_SIMPLEX, FONT_SCALE,
                    (255, 255, 255), FONT_THICK)

        # ── Violation badge ───────────────────────────────
        if violating:
            badge = "⚠ WRONG PARKING"
            (bw, bh), _ = cv2.getTextSize(badge, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
            bx = x1 + (x2 - x1 - bw) // 2
            by = y2 + bh + 8
            cv2.rectangle(frame, (bx-3, by-bh-4), (bx+bw+3, by+3),
                          (0, 0, 180), -1)
            cv2.putText(frame, badge, (bx, by),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        # ── Trajectory ────────────────────────────────────
        traj = list(track.trajectory)
        for i in range(1, len(traj)):
            alpha = i / len(traj)
            colour = (
                int(COLOUR["track_line"][0] * alpha),
                int(COLOUR["track_line"][1] * alpha),
                int(COLOUR["track_line"][2] * alpha),
            )
            cv2.line(frame, traj[i-1], traj[i], colour, 1)

        # ── Centroid dot ──────────────────────────────────
        cv2.circle(frame, track.centroid, 4, box_colour, -1)

    # ══════════════════════════════════════════════════════
    # Utilities
    # ══════════════════════════════════════════════════════
    def _parse_results(self, results) -> list:
        detections = []
        boxes = results.boxes
        if boxes is None:
            return detections
        for box in boxes:
            cls  = int(box.cls[0])
            conf = float(box.conf[0])
            xyxy = box.xyxy[0].cpu().numpy().astype(int)
            x1, y1, x2, y2 = xyxy
            detections.append(((x1, y1, x2, y2), cls, conf))
        return detections

    def _resize(self, frame: np.ndarray) -> np.ndarray:
        if FRAME_RESIZE_WIDTH and frame.shape[1] != FRAME_RESIZE_WIDTH:
            scale = FRAME_RESIZE_WIDTH / frame.shape[1]
            nh    = int(frame.shape[0] * scale)
            frame = cv2.resize(frame, (FRAME_RESIZE_WIDTH, nh))
        return frame

    def _calc_fps(self, t0: float) -> float:
        elapsed = time.perf_counter() - t0
        self._fps_buf.append(1.0 / max(elapsed, 1e-6))
        if len(self._fps_buf) > 30:
            self._fps_buf.pop(0)
        return sum(self._fps_buf) / len(self._fps_buf)
