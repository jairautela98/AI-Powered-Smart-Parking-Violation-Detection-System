"""
=============================================================
  AI Parking Violation Detection System — Configuration
=============================================================
  Author  : AI Parking System
  Version : 2.0.0
  Stack   : Python · OpenCV · YOLOv8 (Ultralytics)
=============================================================
"""

import os
from dataclasses import dataclass, field
from typing import Tuple, List


# ─────────────────────────────────────────────
#  PATHS
# ─────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
ZONES_DIR  = os.path.join(BASE_DIR, "zones")
LOGS_DIR   = os.path.join(BASE_DIR, "logs")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")

for _d in (ZONES_DIR, LOGS_DIR, OUTPUT_DIR, ASSETS_DIR):
    os.makedirs(_d, exist_ok=True)


# ─────────────────────────────────────────────
#  YOLO MODEL
# ─────────────────────────────────────────────
YOLO_MODEL        = "yolov8n.pt"          # nano  | yolov8s.pt | yolov8m.pt | yolov8l.pt
YOLO_CONF         = 0.45                  # confidence threshold
YOLO_IOU          = 0.45                  # NMS IoU threshold
YOLO_DEVICE       = "cpu"                 # "cpu" | "cuda" | "mps"
YOLO_IMG_SIZE     = 640                   # inference image size

# COCO class IDs for vehicles
VEHICLE_CLASS_IDS = [2, 3, 5, 7]         # car, motorcycle, bus, truck
VEHICLE_NAMES     = {
    2: "Car",
    3: "Motorcycle",
    5: "Bus",
    7: "Truck",
}


# ─────────────────────────────────────────────
#  TRACKER
# ─────────────────────────────────────────────
MAX_DISAPPEARED   = 40    # frames before track is deleted
MAX_DISTANCE      = 120   # px — max centroid distance for re-ID
IOU_THRESHOLD     = 0.3   # min IoU for track association


# ─────────────────────────────────────────────
#  VIOLATION RULES
# ─────────────────────────────────────────────
VIOLATION_FRAME_THRESHOLD = 20   # consecutive frames before raising alert
OVERLAP_RATIO_THRESHOLD   = 0.35  # fraction of bbox in restricted zone


# ─────────────────────────────────────────────
#  DISPLAY
# ─────────────────────────────────────────────
SHOW_FPS           = True
SHOW_TRACK_ID      = True
SHOW_CLASS_LABEL   = True
SHOW_CONFIDENCE    = True
SHOW_ZONE_LABELS   = True
SHOW_VIOLATION_BOX = True
FRAME_RESIZE_WIDTH = 1280          # 0 → no resize

# Zone overlay alpha
ZONE_ALPHA = 0.30

# Colours  (BGR)
COLOUR = {
    "no_parking"    : (0,   0,   200),   # red
    "restricted"    : (0,  140,  255),   # orange
    "allowed"       : (0,  200,   50),   # green
    "violation_box" : (0,   0,   255),   # bright red
    "normal_box"    : (50, 205,   50),   # lime green
    "track_line"    : (255, 200,   0),   # gold
    "text_bg"       : (20,  20,   20),
    "text_fg"       : (255, 255, 255),
    "alert_banner"  : (0,   0,   200),
    "fps_text"      : (0,  255, 200),
}

FONT_SCALE  = 0.55
FONT_THICK  = 1
BOX_THICK   = 2


# ─────────────────────────────────────────────
#  VIDEO / CAMERA
# ─────────────────────────────────────────────
DEFAULT_SOURCE   = 0            # 0 = webcam | "path/to/video.mp4"
OUTPUT_FPS       = 25.0
OUTPUT_CODEC     = "mp4v"
SAVE_OUTPUT      = True

# ─────────────────────────────────────────────
#  ALERT / LOGGING
# ─────────────────────────────────────────────
LOG_VIOLATIONS   = True
SNAPSHOT_VIOLATIONS = True      # save frame snapshot on violation
ALERT_COOLDOWN   = 60           # seconds between repeat alerts for same track


# ─────────────────────────────────────────────
#  DATACLASSES
# ─────────────────────────────────────────────
@dataclass
class ZoneConfig:
    zone_id   : int
    name      : str
    zone_type : str          # "no_parking" | "restricted" | "allowed"
    points    : List[Tuple[int, int]] = field(default_factory=list)
    active    : bool = True
