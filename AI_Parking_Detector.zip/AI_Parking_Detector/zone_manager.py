"""
zone_manager.py
────────────────────────────────────────────────────────────
Manages parking zones: load/save, polygon hit-testing,
overlap ratio computation, and interactive drawing tool.
────────────────────────────────────────────────────────────
"""

from __future__ import annotations
import json, os, time
from typing import List, Tuple, Optional, Dict

import cv2
import numpy as np

from config import (
    ZONES_DIR, COLOUR, ZONE_ALPHA,
    SHOW_ZONE_LABELS, ZoneConfig,
    OVERLAP_RATIO_THRESHOLD,
)


# ═══════════════════════════════════════════════════════════
class ParkingZone:
    """Single polygon zone with type and violation logic."""

    TYPE_COLOURS = {
        "no_parking"  : COLOUR["no_parking"],
        "restricted"  : COLOUR["restricted"],
        "allowed"     : COLOUR["allowed"],
    }

    def __init__(self, cfg: ZoneConfig):
        self.zone_id   = cfg.zone_id
        self.name      = cfg.name
        self.zone_type = cfg.zone_type
        self.points    = cfg.points          # [(x,y), ...]
        self.active    = cfg.active
        self._poly     = np.array(self.points, dtype=np.int32) if self.points else None

    # ── Geometry ───────────────────────────────────────────
    def contains_point(self, x: int, y: int) -> bool:
        if self._poly is None or len(self._poly) < 3:
            return False
        return cv2.pointPolygonTest(self._poly, (float(x), float(y)), False) >= 0

    def overlap_ratio(self, bbox: Tuple[int, int, int, int]) -> float:
        """
        Returns fraction of the bounding box that overlaps this zone.
        bbox = (x1, y1, x2, y2)
        """
        if self._poly is None or len(self._poly) < 3:
            return 0.0
        x1, y1, x2, y2 = bbox
        box_area = max((x2 - x1) * (y2 - y1), 1)

        # Create a mask big enough for both shapes
        h = max(y2 + 10, self._poly[:, 1].max() + 10)
        w = max(x2 + 10, self._poly[:, 0].max() + 10)
        zone_mask = np.zeros((h, w), dtype=np.uint8)
        box_mask  = np.zeros((h, w), dtype=np.uint8)

        cv2.fillPoly(zone_mask, [self._poly], 255)
        cv2.rectangle(box_mask, (x1, y1), (x2, y2), 255, -1)

        intersection = cv2.bitwise_and(zone_mask, box_mask)
        inter_pixels = cv2.countNonZero(intersection)
        return inter_pixels / box_area

    def is_violating(self, bbox: Tuple[int, int, int, int]) -> bool:
        if not self.active or self.zone_type == "allowed":
            return False
        return self.overlap_ratio(bbox) >= OVERLAP_RATIO_THRESHOLD

    # ── Drawing ────────────────────────────────────────────
    def draw(self, frame: np.ndarray, show_label: bool = True) -> None:
        if self._poly is None or len(self._poly) < 3:
            return
        colour = self.TYPE_COLOURS.get(self.zone_type, (128, 128, 128))

        overlay = frame.copy()
        cv2.fillPoly(overlay, [self._poly], colour)
        cv2.addWeighted(overlay, ZONE_ALPHA, frame, 1 - ZONE_ALPHA, 0, frame)
        cv2.polylines(frame, [self._poly], True, colour, 2)

        if show_label and SHOW_ZONE_LABELS:
            cx = int(self._poly[:, 0].mean())
            cy = int(self._poly[:, 1].mean())
            label = f"[{self.zone_id}] {self.name}"
            sub   = f"({self.zone_type.upper()})"
            _draw_text_with_bg(frame, label, (cx - 60, cy - 8),  colour)
            _draw_text_with_bg(frame, sub,   (cx - 40, cy + 14), colour)

    def to_dict(self) -> dict:
        return {
            "zone_id"   : self.zone_id,
            "name"      : self.name,
            "zone_type" : self.zone_type,
            "points"    : self.points,
            "active"    : self.active,
        }


# ═══════════════════════════════════════════════════════════
class ZoneManager:
    """Loads, saves, and queries all parking zones."""

    def __init__(self, zones_file: str = "zones/parking_zones.json"):
        self.zones_file = zones_file
        self.zones: List[ParkingZone] = []
        self._load()

    # ── Persistence ────────────────────────────────────────
    def _load(self) -> None:
        if os.path.exists(self.zones_file):
            with open(self.zones_file) as f:
                data = json.load(f)
            for z in data.get("zones", []):
                self.zones.append(ParkingZone(ZoneConfig(**z)))
            print(f"[ZoneManager] Loaded {len(self.zones)} zones from '{self.zones_file}'")
        else:
            print(f"[ZoneManager] No zone file found — starting fresh.")

    def save(self) -> None:
        os.makedirs(os.path.dirname(self.zones_file) or ".", exist_ok=True)
        with open(self.zones_file, "w") as f:
            json.dump({"zones": [z.to_dict() for z in self.zones]}, f, indent=2)
        print(f"[ZoneManager] Saved {len(self.zones)} zones → '{self.zones_file}'")

    # ── CRUD ───────────────────────────────────────────────
    def add_zone(self, name: str, zone_type: str,
                 points: List[Tuple[int, int]]) -> ParkingZone:
        zone_id = max((z.zone_id for z in self.zones), default=0) + 1
        cfg = ZoneConfig(zone_id=zone_id, name=name,
                         zone_type=zone_type, points=points)
        zone = ParkingZone(cfg)
        self.zones.append(zone)
        return zone

    def remove_zone(self, zone_id: int) -> bool:
        before = len(self.zones)
        self.zones = [z for z in self.zones if z.zone_id != zone_id]
        return len(self.zones) < before

    def get_zone(self, zone_id: int) -> Optional[ParkingZone]:
        return next((z for z in self.zones if z.zone_id == zone_id), None)

    # ── Queries ────────────────────────────────────────────
    def check_bbox(self, bbox: Tuple[int, int, int, int]) \
            -> Tuple[bool, Optional[ParkingZone]]:
        """Returns (is_violation, worst_zone)."""
        for zone in self.zones:
            if zone.is_violating(bbox):
                return True, zone
        return False, None

    def get_all_violations(self, bbox: Tuple[int, int, int, int]) \
            -> List[ParkingZone]:
        return [z for z in self.zones if z.is_violating(bbox)]

    # ── Rendering ──────────────────────────────────────────
    def draw_all(self, frame: np.ndarray) -> None:
        for zone in self.zones:
            zone.draw(frame)


# ═══════════════════════════════════════════════════════════
class InteractiveZoneDrawer:
    """
    OpenCV-based interactive tool to draw parking zones.

    Controls
    ────────
    Left-click  → add vertex
    Right-click → undo last vertex
    Enter / 'f' → finish current zone
    'n'         → next zone type  (no_parking → restricted → allowed)
    'd'         → delete last zone
    's'         → save zones
    'q' / ESC   → quit
    """

    TYPES = ["no_parking", "restricted", "allowed"]

    def __init__(self, frame: np.ndarray,
                 zone_manager: ZoneManager,
                 zone_name_prefix: str = "Zone"):
        self.frame        = frame.copy()
        self.zm           = zone_manager
        self.prefix       = zone_name_prefix
        self.current_pts  : List[Tuple[int, int]] = []
        self.type_idx     = 0
        self.hover        = (0, 0)
        self._done        = False

    @property
    def current_type(self) -> str:
        return self.TYPES[self.type_idx]

    def _mouse_cb(self, event, x, y, flags, _):
        self.hover = (x, y)
        if event == cv2.EVENT_LBUTTONDOWN:
            self.current_pts.append((x, y))
        elif event == cv2.EVENT_RBUTTONDOWN and self.current_pts:
            self.current_pts.pop()

    def _render(self) -> np.ndarray:
        canvas = self.frame.copy()
        self.zm.draw_all(canvas)

        colour = ParkingZone.TYPE_COLOURS[self.current_type]
        pts = self.current_pts

        # Draw existing vertices + polygon-in-progress
        for i, pt in enumerate(pts):
            cv2.circle(canvas, pt, 5, colour, -1)
            if i > 0:
                cv2.line(canvas, pts[i - 1], pt, colour, 2)
        if len(pts) > 1:
            cv2.line(canvas, pts[-1], self.hover, colour, 1)
        if len(pts) > 2:
            cv2.line(canvas, pts[-1], self.hover, colour, 1)

        # HUD
        hud = [
            f"Type : {self.current_type.upper()}  [n=next type]",
            f"Pts  : {len(pts)}   [LClick=add  RClick=undo]",
            "Enter/f = finish zone | d = delete last | s = save | q = quit",
        ]
        for i, line in enumerate(hud):
            cv2.putText(canvas, line, (10, 24 + i * 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1)
        return canvas

    def run(self) -> None:
        win = "Zone Editor — Press 'q' to quit"
        cv2.namedWindow(win)
        cv2.setMouseCallback(win, self._mouse_cb)

        while True:
            cv2.imshow(win, self._render())
            key = cv2.waitKey(30) & 0xFF

            if key in (13, ord('f')):          # Enter / f → finish
                if len(self.current_pts) >= 3:
                    name = f"{self.prefix} {len(self.zm.zones) + 1}"
                    self.zm.add_zone(name, self.current_type, self.current_pts)
                    print(f"[ZoneDrawer] Added zone '{name}' ({self.current_type})")
                    self.current_pts = []
                else:
                    print("[ZoneDrawer] Need at least 3 points.")

            elif key == ord('n'):              # cycle zone type
                self.type_idx = (self.type_idx + 1) % len(self.TYPES)
                print(f"[ZoneDrawer] Type → {self.current_type}")

            elif key == ord('d'):              # delete last zone
                if self.zm.zones:
                    removed = self.zm.zones.pop()
                    print(f"[ZoneDrawer] Deleted zone '{removed.name}'")

            elif key == ord('s'):              # save
                self.zm.save()

            elif key in (ord('q'), 27):        # quit
                break

        cv2.destroyWindow(win)


# ═══════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════
def _draw_text_with_bg(img, text, org, colour,
                        font=cv2.FONT_HERSHEY_SIMPLEX,
                        scale=0.48, thickness=1):
    (tw, th), bl = cv2.getTextSize(text, font, scale, thickness)
    x, y = org
    cv2.rectangle(img, (x - 3, y - th - 4), (x + tw + 3, y + bl), colour, -1)
    cv2.putText(img, text, (x, y), font, scale, (255, 255, 255), thickness)


def load_default_demo_zones(zm: ZoneManager, frame_w: int, frame_h: int) -> None:
    """Add sample zones if none exist (for quick demo)."""
    if zm.zones:
        return
    W, H = frame_w, frame_h
    zones_cfg = [
        ("No-Parking Zone A", "no_parking",
         [(int(W*0.05), int(H*0.50)), (int(W*0.25), int(H*0.50)),
          (int(W*0.25), int(H*0.95)), (int(W*0.05), int(H*0.95))]),
        ("No-Parking Zone B", "no_parking",
         [(int(W*0.75), int(H*0.50)), (int(W*0.95), int(H*0.50)),
          (int(W*0.95), int(H*0.95)), (int(W*0.75), int(H*0.95))]),
        ("Restricted Zone", "restricted",
         [(int(W*0.35), int(H*0.55)), (int(W*0.65), int(H*0.55)),
          (int(W*0.65), int(H*0.95)), (int(W*0.35), int(H*0.95))]),
        ("Allowed Parking", "allowed",
         [(int(W*0.27), int(H*0.55)), (int(W*0.33), int(H*0.55)),
          (int(W*0.33), int(H*0.95)), (int(W*0.27), int(H*0.95))]),
    ]
    for name, ztype, pts in zones_cfg:
        zm.add_zone(name, ztype, pts)
    zm.save()
    print(f"[ZoneManager] Loaded {len(zm.zones)} default demo zones.")
