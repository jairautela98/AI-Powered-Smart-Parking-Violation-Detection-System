"""
demo.py
────────────────────────────────────────────────────────────
Synthetic demo — simulates moving vehicles on a parking-lot
background so you can evaluate the system without a camera
or video file.

Run:
    python demo.py
or:
    python main.py --demo
────────────────────────────────────────────────────────────
"""

from __future__ import annotations
import math, random, time
from dataclasses import dataclass, field
from typing import List, Tuple

import cv2
import numpy as np

from config import VEHICLE_NAMES, COLOUR
from zone_manager import ZoneManager, load_default_demo_zones
from vehicle_tracker import VehicleTracker
from alert_system import AlertSystem


# ──────────────────────────────────────────────
DEMO_W, DEMO_H = 1280, 720
FPS            = 25
DURATION_SEC   = 60      # run for N seconds (0 = infinite)
# ──────────────────────────────────────────────


@dataclass
class SyntheticVehicle:
    vid     : int
    x       : float
    y       : float
    w       : int
    h       : int
    vx      : float = 0.0
    vy      : float = 0.0
    class_id: int   = 2          # car
    parked  : bool  = False
    park_timer: int = 0
    colour  : Tuple[int,int,int] = field(default_factory=lambda: (
        random.randint(60,200), random.randint(60,200), random.randint(60,200)))

    @property
    def bbox(self) -> Tuple[int,int,int,int]:
        x1 = int(self.x - self.w / 2)
        y1 = int(self.y - self.h / 2)
        return x1, y1, x1 + self.w, y1 + self.h

    @property
    def centroid(self) -> Tuple[int,int]:
        return int(self.x), int(self.y)

    def step(self) -> None:
        if self.parked:
            self.park_timer -= 1
            if self.park_timer <= 0:
                self.parked = False
                self.vx = random.uniform(-2, 2)
                self.vy = random.uniform(-1.5, 1.5)
            return

        self.x += self.vx
        self.y += self.vy

        # Bounce off walls
        if self.x < self.w//2 or self.x > DEMO_W - self.w//2:
            self.vx *= -1
        if self.y < self.h//2 or self.y > DEMO_H - self.h//2:
            self.vy *= -1

        self.x = max(self.w//2, min(DEMO_W - self.w//2, self.x))
        self.y = max(self.h//2, min(DEMO_H - self.h//2, self.y))

        # Random parking
        if random.random() < 0.003:
            self.parked    = True
            self.park_timer = random.randint(80, 250)
            self.vx = self.vy = 0.0


# ══════════════════════════════════════════════
def _make_background(w: int, h: int) -> np.ndarray:
    """Synthesize a simple parking-lot background."""
    bg = np.full((h, w, 3), 55, dtype=np.uint8)

    # Road surface
    cv2.rectangle(bg, (0, int(h*0.45)), (w, h), (70, 70, 70), -1)

    # Parking lines
    line_w = 60
    for col_start in range(int(w*0.05), w, line_w + 20):
        cv2.rectangle(bg, (col_start, int(h*0.48)),
                      (col_start + line_w, h - 10),
                      (90, 90, 90), -1)
        cv2.rectangle(bg, (col_start, int(h*0.48)),
                      (col_start + line_w, h - 10),
                      (130, 130, 130), 1)

    # Sidewalk
    cv2.rectangle(bg, (0, 0), (w, int(h*0.45)), (100, 90, 80), -1)
    cv2.line(bg, (0, int(h*0.45)), (w, int(h*0.45)), (200, 200, 200), 3)

    # Some greenery
    for _ in range(12):
        cx = random.randint(0, w)
        cy = random.randint(0, int(h*0.43))
        cv2.circle(bg, (cx, cy), random.randint(20, 50), (30, 100, 30), -1)

    return bg


def _spawn_vehicles(n: int) -> List[SyntheticVehicle]:
    vehicles = []
    class_ids = [2, 3, 5, 7]   # car, moto, bus, truck
    sizes = {2: (70,38), 3:(45,28), 5:(110,48), 7:(95,44)}
    for i in range(n):
        cid = random.choice(class_ids)
        w, h = sizes[cid]
        v = SyntheticVehicle(
            vid=i,
            x=random.randint(w, DEMO_W - w),
            y=random.randint(int(DEMO_H*0.5), DEMO_H - h//2),
            w=w, h=h,
            vx=random.uniform(-2.5, 2.5),
            vy=random.uniform(-1.2, 1.2),
            class_id=cid,
        )
        vehicles.append(v)
    return vehicles


def _draw_vehicle(frame: np.ndarray, sv: SyntheticVehicle,
                  track_id: int, violating: bool) -> None:
    x1, y1, x2, y2 = sv.bbox
    col   = COLOUR["violation_box"] if violating else sv.colour
    thick = 3 if violating else 2
    cv2.rectangle(frame, (x1, y1), (x2, y2), col, thick)

    # Roof & windshield illusion
    roof_y = y1 + (y2 - y1) // 4
    cv2.rectangle(frame, (x1 + 8, y1), (x2 - 8, roof_y), sv.colour, -1)
    cv2.rectangle(frame, (x1, roof_y), (x2, y2), sv.colour, -1)
    cv2.rectangle(frame, (x1, y1), (x2, y2), col, thick)

    label = f"ID:{track_id} {VEHICLE_NAMES.get(sv.class_id,'V')}"
    cv2.putText(frame, label, (x1, y1 - 6),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                (0,0,0), 3)
    cv2.putText(frame, label, (x1, y1 - 6),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                (255, 255, 255), 1)

    if violating:
        cv2.putText(frame, "VIOLATION!", (x1, y2 + 16),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)


# ══════════════════════════════════════════════
def run_demo(n_vehicles: int = 12,
             zones_file: str = "zones/parking_zones.json") -> None:

    print("\n[Demo] Starting synthetic parking demo …")
    print("[Demo] Press 'q' or ESC to quit.\n")

    background = _make_background(DEMO_W, DEMO_H)
    zm         = ZoneManager(zones_file)
    load_default_demo_zones(zm, DEMO_W, DEMO_H)

    tracker = VehicleTracker()
    alerts  = AlertSystem()
    vehicles = _spawn_vehicles(n_vehicles)

    frame_no  = 0
    t_start   = time.time()
    fps_buf   = []

    cv2.namedWindow("AI Parking Demo", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("AI Parking Demo", DEMO_W, DEMO_H)

    while True:
        if DURATION_SEC and (time.time() - t_start) > DURATION_SEC:
            break

        t0 = time.perf_counter()
        frame_no += 1

        # ── Simulate ──────────────────────────────────────
        for sv in vehicles:
            sv.step()

        # ── Feed fake detections into tracker ─────────────
        detections = [
            (sv.bbox, sv.class_id, round(random.uniform(0.70, 0.96), 2))
            for sv in vehicles
        ]
        tracks = tracker.update(detections)

        # ── Build frame ───────────────────────────────────
        frame = background.copy()
        zm.draw_all(frame)

        active_violations = 0
        for sv, track in zip(vehicles, tracks):
            zones = zm.get_all_violations(track.bbox)
            new_v = track.update_violation(
                bool(zones),
                [z.zone_id for z in zones],
                threshold=15,
            )
            if new_v:
                alerts.raise_violation(
                    track.track_id, track.class_id,
                    zones, frame, frame_no,
                    track.bbox, track.parking_duration,
                )
            if track.violating:
                active_violations += 1
            _draw_vehicle(frame, sv, track.track_id, track.violating)

        elapsed = time.perf_counter() - t0
        fps = 1.0 / max(elapsed, 1e-6)
        fps_buf.append(fps)
        if len(fps_buf) > 30:
            fps_buf.pop(0)
        avg_fps = sum(fps_buf) / len(fps_buf)

        alerts.tick(len(tracks))
        alerts.draw_hud(frame, fps=avg_fps,
                        active_vehicles=len(tracks),
                        active_violations=active_violations)

        cv2.imshow("AI Parking Demo", frame)
        key = cv2.waitKey(max(1, int(1000/FPS))) & 0xFF
        if key in (ord('q'), 27):
            break

    cv2.destroyAllWindows()
    alerts.save_session_report()
    print("[Demo] Finished.")


if __name__ == "__main__":
    run_demo()
