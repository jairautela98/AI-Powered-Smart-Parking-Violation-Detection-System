# 🚗 AI Parking Violation Detection System

> **Detect wrong & no-parking violations in real-time across multiple vehicles**  
> using **Python · OpenCV · YOLOv8 (Ultralytics)**

---

## 📌 Overview

This project is a production-ready **Artificial Intelligence Vehicle Parking Violation Detection System** that:

- 🎯 **Detects** Cars, Trucks, Buses, and Motorcycles using **YOLOv8**
- 🗺️ **Monitors** user-defined **No-Parking**, **Restricted**, and **Allowed** polygon zones
- 🔁 **Tracks** multiple vehicles simultaneously with a custom centroid + IoU tracker
- ⚠️ **Raises alerts** with frame snapshots, CSV logs, and on-screen banners
- 🎨 **Visualizes** zones, trajectories, violation badges, and live HUD

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                  Video / Camera Source                  │
└──────────────────────────┬──────────────────────────────┘
                           │
               ┌───────────▼───────────┐
               │   YOLOv8 Inference    │  ← Detects vehicles
               │  (Ultralytics YOLO)   │    (car, truck, bus, moto)
               └───────────┬───────────┘
                           │ detections [(bbox, class, conf)]
               ┌───────────▼───────────┐
               │   Vehicle Tracker     │  ← Assigns & maintains
               │  (Centroid + IoU)     │    unique Track IDs
               └───────────┬───────────┘
                           │ tracks [VehicleTrack]
               ┌───────────▼───────────┐
               │   Zone Manager        │  ← Polygon overlap check
               │  (No-Park / Restrict) │    per vehicle bbox
               └───────────┬───────────┘
                           │ violations
               ┌───────────▼───────────┐
               │   Alert System        │  ← CSV log, snapshots,
               │  (Log + Snapshot)     │    on-screen banners
               └───────────┬───────────┘
                           │
               ┌───────────▼───────────┐
               │  Annotated Output     │  ← Display + save video
               └───────────────────────┘
```

---

## 📁 Project Structure

```
AI_Parking_Detector/
│
├── main.py                  # ← Entry point (CLI)
├── config.py                # ← All tunable parameters
├── parking_detector.py      # ← Core detection pipeline
├── zone_manager.py          # ← Zone polygon CRUD & overlap math
├── vehicle_tracker.py       # ← Multi-object tracker
├── alert_system.py          # ← Violation logging & alerts
├── demo.py                  # ← Synthetic demo (no camera needed)
│
├── zones/
│   └── parking_zones.json   # ← Saved zone definitions
│
├── logs/
│   ├── violations_*.csv     # ← Per-session violation log
│   └── session_*.json       # ← Full session report
│
├── output/
│   ├── snapshots_*/         # ← Per-violation frame crops
│   └── parking_output_*.mp4 # ← Saved annotated video
│
└── requirements.txt
```

---

## ⚡ Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

> YOLOv8 weights (`yolov8n.pt`) download automatically on first run.

### 2. Run the synthetic demo (no camera needed)

```bash
python demo.py
```

### 3. Run with a webcam

```bash
python main.py
```

### 4. Run with a video file

```bash
python main.py --source path/to/parking_lot.mp4 --save
```

### 5. Draw custom parking zones first

```bash
python main.py --source video.mp4 --draw-zones
```

### 6. RTSP camera stream (IP camera)

```bash
python main.py --source rtsp://admin:password@192.168.1.100/stream1 --save
```

---

## 🗺️ Zone Editor Controls

Launch with `--draw-zones` flag.

| Key / Action | Effect |
|---|---|
| **Left-click** | Add polygon vertex |
| **Right-click** | Undo last vertex |
| **Enter / `f`** | Finish & save current zone |
| **`n`** | Cycle zone type (No-Parking → Restricted → Allowed) |
| **`d`** | Delete last zone |
| **`s`** | Save zones to JSON |
| **`q` / ESC** | Quit editor |

---

## 🔧 Configuration (`config.py`)

| Parameter | Default | Description |
|---|---|---|
| `YOLO_MODEL` | `yolov8n.pt` | Model size: n / s / m / l / x |
| `YOLO_CONF` | `0.45` | Detection confidence threshold |
| `YOLO_DEVICE` | `"cpu"` | `"cpu"` / `"cuda"` / `"mps"` |
| `VIOLATION_FRAME_THRESHOLD` | `20` | Frames in zone before alert |
| `OVERLAP_RATIO_THRESHOLD` | `0.35` | Min bbox-zone overlap (0–1) |
| `MAX_DISAPPEARED` | `40` | Frames until track is dropped |
| `ALERT_COOLDOWN` | `60` | Seconds between repeat alerts |
| `FRAME_RESIZE_WIDTH` | `1280` | Input resize (0 = no resize) |

---

## 📊 Output Files

### `logs/violations_TIMESTAMP.csv`

```
violation_id, track_id, class_name, zone_names, zone_types,
timestamp, frame_number, bbox, snapshot_path, duration_sec
```

### `logs/session_TIMESTAMP.json`

```json
{
  "run_id": "20240601_143022",
  "duration_seconds": 180.3,
  "frames_processed": 4500,
  "total_violations": 7,
  "violations": [...]
}
```

---

## 🎨 Zone Types

| Zone Type | Colour | Behaviour |
|---|---|---|
| **No-Parking** | 🔴 Red | Any vehicle triggers violation |
| **Restricted** | 🟠 Orange | Triggers violation after threshold |
| **Allowed** | 🟢 Green | No violation — informational only |

---

## 📹 Keyboard Controls (Live Window)

| Key | Action |
|---|---|
| `q` / ESC | Quit |
| `s` | Save current frame snapshot |
| `p` | Pause / unpause |

---

## 🚀 Advanced Usage

### Use a larger, more accurate model

```bash
python main.py --source video.mp4 --model yolov8l
```

### Headless server mode (no display)

```bash
python main.py --source rtsp://... --save --no-preview
```

### GPU acceleration (CUDA)

Edit `config.py`:
```python
YOLO_DEVICE = "cuda"
```

---

## 🏆 Key Features

- ✅ **Multi-vehicle, multi-zone** simultaneous monitoring
- ✅ **Polygon zones** (arbitrary shapes, not just rectangles)
- ✅ **Vehicle trajectory** visualization per track
- ✅ **Flashing violation** bounding box animation
- ✅ **Snapshot** crops saved per violation
- ✅ **CSV + JSON** structured logs
- ✅ **Cooldown** system prevents alert spam
- ✅ **Synthetic demo** mode (no camera required)
- ✅ **Interactive zone editor** with live preview
- ✅ **RTSP / webcam / file** source support
- ✅ **GPU-ready** (CUDA / MPS)

---

## 📜 License

MIT License — free for academic and commercial use.

---

*Built with ❤️ using Python · OpenCV · YOLOv8 (Ultralytics)*
