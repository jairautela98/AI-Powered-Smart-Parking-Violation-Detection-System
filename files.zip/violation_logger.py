"""
violation_logger.py
───────────────────
Records parking violations to an in-memory list, exports to CSV,
and saves frame snapshots for evidence.
"""

import csv
import cv2
from datetime import datetime
from pathlib import Path


class ViolationLogger:
    """Lightweight logger for parking violations."""

    CSV_FIELDS = [
        "timestamp", "frame_idx", "track_id",
        "vehicle_class", "status", "zone_name",
        "centroid_x", "centroid_y", "confidence",
        "snapshot_path",
    ]

    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.snapshots_dir = self.output_dir / "snapshots"
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)

        self.records: list[dict] = []
        self.total = 0

    # ── Logging ────────────────────────────────────────────────────────────────

    def log(self, vehicle: dict, status: str, zone_name: str | None, frame_idx: int):
        """Append one violation record."""
        self.total += 1
        ts = datetime.now().isoformat(timespec="seconds")
        cx, cy = vehicle["centroid"]
        record = {
            "timestamp":     ts,
            "frame_idx":     frame_idx,
            "track_id":      vehicle["track_id"],
            "vehicle_class": vehicle["class"],
            "status":        status,
            "zone_name":     zone_name or "N/A",
            "centroid_x":    cx,
            "centroid_y":    cy,
            "confidence":    f"{vehicle['confidence']:.3f}",
            "snapshot_path": "",   # filled in by save_snapshot()
        }
        self.records.append(record)
        print(
            f"[VIOLATION #{self.total}] "
            f"Track#{vehicle['track_id']} {vehicle['class'].upper()} | "
            f"{status} | Zone: {zone_name or 'none'} | Frame {frame_idx}"
        )

    def save_snapshot(self, frame, track_id: int, status: str) -> str:
        """Crop and save the current frame as a snapshot."""
        ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:20]
        filename = f"{ts}_id{track_id}_{status}.jpg"
        path = self.snapshots_dir / filename
        cv2.imwrite(str(path), frame)

        # Back-fill path into latest record for this track
        for r in reversed(self.records):
            if r["track_id"] == track_id and r["snapshot_path"] == "":
                r["snapshot_path"] = str(path)
                break
        return str(path)

    def export_csv(self):
        """Write all records to output/violations.csv."""
        if not self.records:
            print("[INFO] No violations to export.")
            return

        out_path = self.output_dir / "violations.csv"
        with open(out_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=self.CSV_FIELDS)
            writer.writeheader()
            writer.writerows(self.records)

        print(f"[INFO] Exported {len(self.records)} violation(s) → {out_path}")

    # ── Summary ────────────────────────────────────────────────────────────────

    def summary(self) -> dict:
        counts: dict[str, int] = {}
        for r in self.records:
            counts[r["status"]] = counts.get(r["status"], 0) + 1
        return counts
