"""
utils.py
────────
Shared OpenCV drawing utilities.
"""

import cv2
import numpy as np


def draw_dashed_polygon(frame: np.ndarray, pts: np.ndarray, color: tuple, thickness: int = 2, gap: int = 8):
    """Draw a polygon outline with a dashed style."""
    n = len(pts)
    for i in range(n):
        p1 = tuple(pts[i])
        p2 = tuple(pts[(i + 1) % n])
        draw_dashed_line(frame, p1, p2, color, thickness, gap)


def draw_dashed_line(frame, p1, p2, color, thickness=2, gap=8):
    """Draw a dashed line between two points."""
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    dist = max(1, int((dx**2 + dy**2) ** 0.5))
    for i in range(0, dist, gap * 2):
        t0 = i / dist
        t1 = min((i + gap) / dist, 1.0)
        x0, y0 = int(p1[0] + dx * t0), int(p1[1] + dy * t0)
        x1, y1 = int(p1[0] + dx * t1), int(p1[1] + dy * t1)
        cv2.line(frame, (x0, y0), (x1, y1), color, thickness)


def put_text_with_bg(
    frame: np.ndarray,
    text: str,
    origin: tuple,
    color: tuple,
    font_scale: float = 0.5,
    thickness: int = 1,
    padding: int = 4,
):
    """Draw text with a semi-transparent background pill."""
    font = cv2.FONT_HERSHEY_SIMPLEX
    (tw, th), baseline = cv2.getTextSize(text, font, font_scale, thickness)
    x, y = origin
    # Clamp so the label never goes above the frame
    y = max(y, th + padding + 2)

    rx1, ry1 = x - padding, y - th - padding
    rx2, ry2 = x + tw + padding, y + baseline + padding

    overlay = frame.copy()
    cv2.rectangle(overlay, (rx1, ry1), (rx2, ry2), (10, 10, 10), -1)
    cv2.addWeighted(overlay, 0.65, frame, 0.35, 0, frame)

    # Coloured left accent bar
    cv2.rectangle(frame, (rx1, ry1), (rx1 + 3, ry2), color, -1)

    cv2.putText(frame, text, (x, y), font, font_scale, (230, 230, 230), thickness, cv2.LINE_AA)


def resize_frame(frame: np.ndarray, width: int = 1280) -> np.ndarray:
    """Proportionally resize frame to the given width."""
    h, w = frame.shape[:2]
    if w <= width:
        return frame
    scale = width / w
    return cv2.resize(frame, (width, int(h * scale)), interpolation=cv2.INTER_AREA)
