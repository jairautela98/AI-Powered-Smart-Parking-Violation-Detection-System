"""
setup_zones.py
──────────────
Interactive CLI tool to define parking zones by clicking on a
reference image or the first frame of a video.

Usage
-----
  python setup_zones.py --source parking_lot.mp4 --output zones.json
  python setup_zones.py --source reference.jpg   --output zones.json
"""

import cv2
import json
import argparse
import numpy as np
from pathlib import Path


ZONE_TYPES   = ["PARKING", "NO_PARKING", "WRONG_ZONE"]
ZONE_COLORS  = {
    "PARKING":    (34,  197,  94),
    "NO_PARKING": (239,  68,  68),
    "WRONG_ZONE": (234, 179,   8),
}


class ZoneSetupTool:
    def __init__(self, frame: np.ndarray, output_path: str):
        self.base_frame  = frame.copy()
        self.output_path = Path(output_path)
        self.zones: list[dict] = []
        self.current_points: list[tuple] = []
        self.canvas = frame.copy()

        # Try to load existing zones
        if self.output_path.exists():
            with open(self.output_path) as f:
                self.zones = json.load(f)
            print(f"[INFO] Loaded {len(self.zones)} existing zone(s) from '{self.output_path}'.")
            self._redraw()

    def _redraw(self):
        """Re-render all committed zones onto the canvas."""
        self.canvas = self.base_frame.copy()
        overlay = self.canvas.copy()
        for z in self.zones:
            pts   = np.array(z["polygon"], dtype=np.int32)
            color = ZONE_COLORS.get(z["type"], (200, 200, 200))
            cv2.fillPoly(overlay, [pts], color)
            cv2.polylines(self.canvas, [pts], True, color, 2)
            M = cv2.moments(pts)
            if M["m00"] != 0:
                lx, ly = int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"])
                cv2.putText(self.canvas, z["name"], (lx - 30, ly),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)
        cv2.addWeighted(overlay, 0.3, self.canvas, 0.7, 0, self.canvas)

    def _draw_in_progress(self, tmp_pt=None):
        """Draw current points + optional live mouse position."""
        disp = self.canvas.copy()
        for p in self.current_points:
            cv2.circle(disp, p, 5, (0, 255, 255), -1)
        if len(self.current_points) > 1:
            cv2.polylines(disp, [np.array(self.current_points)], False, (0, 255, 255), 2)
        if tmp_pt and self.current_points:
            cv2.line(disp, self.current_points[-1], tmp_pt, (0, 200, 200), 1)
        cv2.imshow("Zone Setup", disp)

    def run(self):
        print("\n═══════════════════════════════════════════")
        print("  AI Parking Zone Setup Tool")
        print("  Left-click  → add vertex")
        print("  Right-click → undo last vertex")
        print("  ENTER       → finish current zone")
        print("  D           → delete last zone")
        print("  S           → save & exit")
        print("  ESC         → quit without saving")
        print("═══════════════════════════════════════════\n")

        cv2.namedWindow("Zone Setup", cv2.WINDOW_NORMAL)

        def on_mouse(event, x, y, flags, _):
            if event == cv2.EVENT_LBUTTONDOWN:
                self.current_points.append((x, y))
                self._draw_in_progress((x, y))
            elif event == cv2.EVENT_RBUTTONDOWN:
                if self.current_points:
                    self.current_points.pop()
                    self._draw_in_progress((x, y))
            elif event == cv2.EVENT_MOUSEMOVE:
                self._draw_in_progress((x, y))

        cv2.setMouseCallback("Zone Setup", on_mouse)
        self._draw_in_progress()

        while True:
            key = cv2.waitKey(20) & 0xFF

            if key in (13, 32) and len(self.current_points) >= 3:   # ENTER / SPACE
                zone_idx  = len(self.zones) + 1
                zone_name = input(f"  Zone name (default: Zone-{zone_idx}): ").strip() or f"Zone-{zone_idx}"
                print(f"  Type options: {' | '.join(ZONE_TYPES)}")
                zone_type = input("  Zone type (default: PARKING): ").strip().upper() or "PARKING"
                if zone_type not in ZONE_TYPES:
                    print(f"  [WARN] Unknown type '{zone_type}', defaulting to PARKING.")
                    zone_type = "PARKING"

                self.zones.append({
                    "name":    zone_name,
                    "type":    zone_type,
                    "polygon": [[p[0], p[1]] for p in self.current_points],
                })
                print(f"  ✓ Zone '{zone_name}' ({zone_type}) added with {len(self.current_points)} vertices.")
                self.current_points = []
                self._redraw()
                self._draw_in_progress()

            elif key == ord("d") and self.zones:
                removed = self.zones.pop()
                print(f"  ✗ Removed zone '{removed['name']}'.")
                self._redraw()
                self._draw_in_progress()

            elif key == ord("s"):
                self._save()
                break

            elif key == 27:  # ESC
                print("[INFO] Exiting without saving.")
                break

        cv2.destroyAllWindows()

    def _save(self):
        with open(self.output_path, "w") as f:
            json.dump(self.zones, f, indent=2)
        print(f"\n[INFO] Saved {len(self.zones)} zone(s) → '{self.output_path}'")


def main():
    p = argparse.ArgumentParser(description="Interactive zone setup tool")
    p.add_argument("--source", required=True, help="Image or video path")
    p.add_argument("--output", default="zones.json", help="Output JSON path")
    args = p.parse_args()

    src = args.source
    if src.lower().endswith((".jpg", ".jpeg", ".png", ".bmp")):
        frame = cv2.imread(src)
        if frame is None:
            raise FileNotFoundError(f"Cannot read image: {src}")
    else:
        cap = cv2.VideoCapture(src)
        ret, frame = cap.read()
        cap.release()
        if not ret:
            raise RuntimeError(f"Cannot read video: {src}")

    tool = ZoneSetupTool(frame, args.output)
    tool.run()


if __name__ == "__main__":
    main()
