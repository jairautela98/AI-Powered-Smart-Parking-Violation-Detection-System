"""
zone_manager.py
───────────────
Loads parking-zone polygons from a JSON config and provides
fast point-in-polygon lookup using OpenCV's pointPolygonTest.
"""

import json
import numpy as np
import cv2
from pathlib import Path


# Default BGR colours per zone type
ZONE_COLORS = {
    "PARKING":    (34,  197,  94),   # green
    "NO_PARKING": (239,  68,  68),   # red
    "WRONG_ZONE": (234, 179,   8),   # amber
}


class ZoneManager:
    """
    Manages a list of named polygon zones loaded from a JSON file.

    JSON schema
    -----------
    [
      {
        "name"    : "Zone-A",
        "type"    : "PARKING | NO_PARKING | WRONG_ZONE",
        "polygon" : [[x1,y1],[x2,y2], … ]   // absolute pixel coords
      },
      …
    ]
    """

    def __init__(self, config_path: str):
        self.config_path = Path(config_path)
        self.zones: list[dict] = []
        self._load()

    # ── I/O ────────────────────────────────────────────────────────────────────

    def _load(self):
        if not self.config_path.exists():
            print(f"[WARN] Zone config not found at '{self.config_path}'. Using empty zone list.")
            return

        with open(self.config_path) as f:
            raw = json.load(f)

        for z in raw:
            ztype = z.get("type", "PARKING").upper()
            self.zones.append(
                {
                    "name":    z["name"],
                    "type":    ztype,
                    "polygon": z["polygon"],
                    "color":   ZONE_COLORS.get(ztype, (200, 200, 200)),
                    "_pts":    np.array(z["polygon"], dtype=np.int32),
                }
            )
        print(f"[INFO] ZoneManager: loaded {len(self.zones)} zone(s) from '{self.config_path}'.")

    def save(self):
        """Persist current zones back to the JSON file."""
        serialisable = [
            {"name": z["name"], "type": z["type"], "polygon": z["polygon"]}
            for z in self.zones
        ]
        with open(self.config_path, "w") as f:
            json.dump(serialisable, f, indent=2)

    # ── Lookup ─────────────────────────────────────────────────────────────────

    def find_zone(self, point: tuple[int, int], zone_type: str | None = None) -> dict | None:
        """
        Return the first zone that contains *point*.

        Parameters
        ----------
        point     : (x, y) pixel coordinate to test.
        zone_type : If given, only zones of this type are considered.

        Returns
        -------
        zone dict or None.
        """
        for zone in self.zones:
            if zone_type and zone["type"] != zone_type.upper():
                continue
            result = cv2.pointPolygonTest(zone["_pts"], point, measureDist=False)
            if result >= 0:
                return zone
        return None

    def get_zone_by_name(self, name: str) -> dict | None:
        for z in self.zones:
            if z["name"] == name:
                return z
        return None

    # ── Interactive zone editor (helper) ───────────────────────────────────────

    @staticmethod
    def interactive_setup(frame: np.ndarray, zone_name: str, zone_type: str) -> list[list[int]]:
        """
        Click polygon vertices on a displayed frame.
        Press ENTER/SPACE to finish, ESC to cancel.

        Returns list of [x, y] points.
        """
        points: list[tuple[int, int]] = []
        clone = frame.copy()
        window = "Zone Setup – click vertices, press ENTER to finish"

        def on_click(event, x, y, flags, _):
            if event == cv2.EVENT_LBUTTONDOWN:
                points.append((x, y))
                cv2.circle(clone, (x, y), 5, (0, 255, 255), -1)
                if len(points) > 1:
                    cv2.line(clone, points[-2], points[-1], (0, 255, 255), 2)
                cv2.imshow(window, clone)

        cv2.namedWindow(window)
        cv2.setMouseCallback(window, on_click)
        cv2.imshow(window, clone)

        while True:
            key = cv2.waitKey(0) & 0xFF
            if key in (13, 32):   # ENTER or SPACE
                break
            if key == 27:         # ESC
                points = []
                break

        cv2.destroyWindow(window)
        print(f"[INFO] Captured {len(points)} points for zone '{zone_name}'.")
        return [[p[0], p[1]] for p in points]
