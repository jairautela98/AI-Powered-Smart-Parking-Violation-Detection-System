"""
============================================================
  AI Parking Violation Detection System
  Author  : Your Name
  License : MIT
  Stack   : Python · OpenCV · Ultralytics YOLOv8
============================================================
"""

import cv2
import json
import time
import argparse
import numpy as np
from pathlib import Path
from datetime import datetime
from ultralytics import YOLO

from zone_manager import ZoneManager
from violation_logger import ViolationLogger
from utils import draw_dashed_polygon, put_text_with_bg, resize_frame


# ── Vehicle classes in COCO that YOLO detects ─────────────────────────────────
VEHICLE_CLASSES = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}


class ParkingViolationDetector:
    """
    Real-time parking-violation detector.

    Workflow
    --------
    1. Load a YOLOv8 model.
    2. Read parking-zone polygons from a JSON config.
    3. For every frame:
       a. Detect vehicles with YOLO.
       b. Classify each detected vehicle as ALLOWED / NO-PARKING / WRONG-ZONE.
       c. Overlay results and log violations.
    """

    def __init__(
        self,
        model_path: str = "yolov8n.pt",
        zones_config: str = "zones.json",
        conf_threshold: float = 0.40,
        output_dir: str = "output",
        save_violations: bool = True,
    ):
        print("[INFO] Loading YOLOv8 model …")
        self.model = YOLO(model_path)
        self.conf_threshold = conf_threshold
        self.save_violations = save_violations

        self.zone_manager = ZoneManager(zones_config)
        self.logger = ViolationLogger(output_dir)

        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Tracking state  {track_id: {"class", "bbox", "zone_status", "first_seen"}}
        self.tracked_vehicles: dict = {}
        # How many consecutive frames a vehicle must be in violation before logging
        self.violation_frames_threshold = 5
        self.violation_frame_counter: dict = {}

        print(f"[INFO] Loaded {len(self.zone_manager.zones)} parking zones.")

    # ── Core detection ─────────────────────────────────────────────────────────

    def detect_vehicles(self, frame: np.ndarray):
        """Run YOLO inference and return only vehicle detections."""
        results = self.model.track(frame, persist=True, conf=self.conf_threshold, verbose=False)
        vehicles = []

        if results[0].boxes is None:
            return vehicles

        boxes = results[0].boxes
        for box in boxes:
            cls_id = int(box.cls[0])
            if cls_id not in VEHICLE_CLASSES:
                continue

            track_id = int(box.id[0]) if box.id is not None else -1
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            cx, cy = (x1 + x2) // 2, (y1 + y2) // 2  # centroid

            vehicles.append(
                {
                    "track_id": track_id,
                    "class": VEHICLE_CLASSES[cls_id],
                    "bbox": (x1, y1, x2, y2),
                    "centroid": (cx, cy),
                    "confidence": conf,
                }
            )
        return vehicles

    def classify_vehicle(self, vehicle: dict) -> tuple[str, str | None]:
        """
        Returns (status, zone_name).

        status  : "ALLOWED" | "WRONG_ZONE" | "NO_PARKING"
        zone_name: name of the zone the vehicle is in (or None)
        """
        cx, cy = vehicle["centroid"]
        point = (cx, cy)

        allowed_zone = self.zone_manager.find_zone(point, zone_type="PARKING")
        if allowed_zone:
            return "ALLOWED", allowed_zone["name"]

        wrong_zone = self.zone_manager.find_zone(point, zone_type="NO_PARKING")
        if wrong_zone:
            return "NO_PARKING", wrong_zone["name"]

        restricted_zone = self.zone_manager.find_zone(point, zone_type="WRONG_ZONE")
        if restricted_zone:
            return "WRONG_ZONE", restricted_zone["name"]

        # Outside all defined zones – treat as no-parking (open road / footpath)
        return "NO_PARKING", None

    # ── Drawing helpers ────────────────────────────────────────────────────────

    def draw_zones(self, frame: np.ndarray) -> np.ndarray:
        """Overlay all parking zones on the frame."""
        overlay = frame.copy()
        for zone in self.zone_manager.zones:
            pts = np.array(zone["polygon"], dtype=np.int32)
            color = zone["color"]

            # Semi-transparent fill
            cv2.fillPoly(overlay, [pts], color)
            # Border
            draw_dashed_polygon(frame, pts, color, thickness=2)
            # Label
            M = cv2.moments(pts)
            if M["m00"] != 0:
                lx = int(M["m10"] / M["m00"])
                ly = int(M["m01"] / M["m00"])
                put_text_with_bg(frame, zone["name"], (lx, ly), color)

        return cv2.addWeighted(overlay, 0.25, frame, 0.75, 0)

    def draw_vehicle(self, frame: np.ndarray, vehicle: dict, status: str, zone_name: str | None):
        """Draw bounding box + status badge for one vehicle."""
        x1, y1, x2, y2 = vehicle["bbox"]
        tid = vehicle["track_id"]
        vclass = vehicle["class"].capitalize()
        conf = vehicle["confidence"]

        colors = {
            "ALLOWED": (34, 197, 94),    # green
            "NO_PARKING": (239, 68, 68),  # red
            "WRONG_ZONE": (234, 179, 8),  # amber
        }
        color = colors[status]

        # Bounding box
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

        # Top label
        label = f"#{tid} {vclass} {conf:.0%}"
        put_text_with_bg(frame, label, (x1, y1 - 8), color)

        # Status badge below box
        status_label = status.replace("_", " ")
        if zone_name:
            status_label += f" [{zone_name}]"
        put_text_with_bg(frame, status_label, (x1, y2 + 4), color, font_scale=0.45)

        # Centroid dot
        cx, cy = vehicle["centroid"]
        cv2.circle(frame, (cx, cy), 5, color, -1)

    # ── Main processing loop ───────────────────────────────────────────────────

    def process_frame(self, frame: np.ndarray, frame_idx: int) -> np.ndarray:
        frame = self.draw_zones(frame)
        vehicles = self.detect_vehicles(frame)

        stats = {"ALLOWED": 0, "NO_PARKING": 0, "WRONG_ZONE": 0}

        for v in vehicles:
            status, zone_name = self.classify_vehicle(v)
            stats[status] += 1
            tid = v["track_id"]

            self.draw_vehicle(frame, v, status, zone_name)

            # Violation debounce counter
            if status != "ALLOWED":
                self.violation_frame_counter[tid] = self.violation_frame_counter.get(tid, 0) + 1
                if self.violation_frame_counter[tid] == self.violation_frames_threshold:
                    self.logger.log(v, status, zone_name, frame_idx)
                    if self.save_violations:
                        self.logger.save_snapshot(frame, tid, status)
            else:
                self.violation_frame_counter[tid] = 0

        self._draw_dashboard(frame, stats)
        return frame

    def _draw_dashboard(self, frame: np.ndarray, stats: dict):
        """Top-right HUD showing live counts."""
        h, w = frame.shape[:2]
        panel_w, panel_h = 240, 110
        x0, y0 = w - panel_w - 10, 10

        overlay = frame.copy()
        cv2.rectangle(overlay, (x0, y0), (x0 + panel_w, y0 + panel_h), (15, 15, 30), -1)
        cv2.addWeighted(overlay, 0.75, frame, 0.25, 0, frame)
        cv2.rectangle(frame, (x0, y0), (x0 + panel_w, y0 + panel_h), (80, 80, 100), 1)

        ts = datetime.now().strftime("%H:%M:%S")
        cv2.putText(frame, f"AI Parking Monitor  {ts}", (x0 + 6, y0 + 18),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (200, 200, 220), 1)

        items = [
            ("Allowed",    stats["ALLOWED"],    (34, 197, 94)),
            ("No Parking", stats["NO_PARKING"], (239, 68, 68)),
            ("Wrong Zone", stats["WRONG_ZONE"], (234, 179, 8)),
        ]
        for i, (label, count, color) in enumerate(items):
            yy = y0 + 38 + i * 24
            cv2.putText(frame, f"{label}:", (x0 + 8, yy),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, (180, 180, 200), 1)
            cv2.putText(frame, str(count), (x0 + panel_w - 28, yy),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.52, color, 2)

    # ── Entry points ───────────────────────────────────────────────────────────

    def run_video(self, source, show: bool = True, save: bool = True):
        cap = cv2.VideoCapture(source)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open source: {source}")

        fps = cap.get(cv2.CAP_PROP_FPS) or 25
        W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        writer = None
        if save:
            out_path = str(self.output_dir / "result.mp4")
            writer = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (W, H))
            print(f"[INFO] Saving output to {out_path}")

        frame_idx = 0
        t0 = time.time()
        print("[INFO] Running detection … press Q to quit.")

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            processed = self.process_frame(frame, frame_idx)

            # FPS overlay
            elapsed = time.time() - t0
            live_fps = frame_idx / elapsed if elapsed > 0 else 0
            cv2.putText(processed, f"FPS: {live_fps:.1f}", (10, 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

            if writer:
                writer.write(processed)
            if show:
                cv2.imshow("AI Parking Violation Detector", processed)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

            frame_idx += 1

        cap.release()
        if writer:
            writer.release()
        cv2.destroyAllWindows()
        self.logger.export_csv()
        print(f"\n[INFO] Processed {frame_idx} frames. Violations logged: {self.logger.total}")


# ── CLI ────────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="AI Parking Violation Detector")
    p.add_argument("--source",  default="0",         help="Video path or webcam index")
    p.add_argument("--model",   default="yolov8n.pt", help="YOLO model weights")
    p.add_argument("--zones",   default="zones.json", help="Zone configuration JSON")
    p.add_argument("--conf",    type=float, default=0.4, help="Detection confidence threshold")
    p.add_argument("--output",  default="output",    help="Output directory")
    p.add_argument("--no-show", action="store_true",  help="Disable live preview")
    p.add_argument("--no-save", action="store_true",  help="Do not save output video")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    source = int(args.source) if args.source.isdigit() else args.source

    detector = ParkingViolationDetector(
        model_path=args.model,
        zones_config=args.zones,
        conf_threshold=args.conf,
        output_dir=args.output,
    )
    detector.run_video(source, show=not args.no_show, save=not args.no_save)
